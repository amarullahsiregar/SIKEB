package main;

import java.sql.*;


public class KoneksiDB {
    public static Connection koneksi;
    public static Statement statement;
    
    String username = "12345678";
    String password = "admin";

    public KoneksiDB() {
        try {
            String url ="jdbc:mysql://localhost/sikeb";
            String user="root";
            String pass="";
            Class.forName("com.mysql.jdbc.Driver");
            
            koneksi =DriverManager.getConnection(url,user,pass);
            ResultSet hasil = koneksi.createStatement().executeQuery("select * from pengguna where id_pengguna='"+username+"'and password='"+password+"' and status_user=2");
            if (hasil.next()) {
                System.out.println("Koneksi Bisa");
            }else{
                System.out.println("Koneksi Gagal");
            }
        } catch (Exception e) {
            System.err.println("koneksi gagal karena " +e.getMessage());
        }
    }
    
}
